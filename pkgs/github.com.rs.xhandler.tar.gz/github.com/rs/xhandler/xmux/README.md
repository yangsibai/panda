Xmux did move to it's [own repository](https://github.com/rs/xmux/blob/master/README.md)
